# Heaps (Priority Queues)

A heap is a complete binary tree satisfying the heap property: a min-heap has the smallest element at the root. Heaps give O(log n) insertion/deletion and O(1) peek. In Java, `PriorityQueue<Integer>` is a min-heap by default; for a max-heap use `Collections.reverseOrder()`. Heaps excel at "top K" and "running median" problems.

---

## Problem List

| # | Problem | Difficulty | LeetCode |
|---|---------|-----------|----------|
| 1 | Last Stone Weight | Easy | [Link](https://leetcode.com/problems/last-stone-weight/) |
| 2 | Kth Largest Element in Array | Medium | [Link](https://leetcode.com/problems/kth-largest-element-in-an-array/) |
| 3 | Top K Frequent Elements | Medium | [Link](https://leetcode.com/problems/top-k-frequent-elements/) |

---

## Approach

**Last Stone Weight:** The brute force sorts the ArrayList on every iteration to find the two heaviest stones — O(n² log n). The optimal max-heap approach (using negated values in Java's min-heap, or `Collections.reverseOrder()`) always pops the two largest in O(log n), making the total O(n log n).

**Kth Largest Element:** The brute force sorts the array descending and returns index k-1 — O(n log n). The optimal min-heap of size k approach keeps exactly the k largest elements seen so far; the heap root is always the smallest among them, i.e. the k-th largest overall. Each offer/poll costs O(log k), so total is O(n log k) — better than O(n log n) when k is small.

**Top K Frequent Elements:** The brute force builds a frequency HashMap then sorts all entries by frequency — O(n log n). The optimal approach maintains a min-heap of size k keyed by frequency; less-frequent elements are evicted as we go. Final heap contains the k most frequent numbers — O(n log k).

---

## Complexity Table

| Problem | Brute Time | Brute Space | Optimal Time | Optimal Space |
|---------|-----------|-------------|-------------|---------------|
| Last Stone Weight | O(n² log n) | O(n) | O(n log n) | O(n) |
| Kth Largest Element | O(n log n) | O(1) | O(n log k) | O(k) |
| Top K Frequent Elements | O(n log n) | O(n) | O(n log k) | O(n + k) |

---

## How to Run

```bash
javac LastStoneWeightBrute.java && java LastStoneWeightBrute
javac LastStoneWeightOptimal.java && java LastStoneWeightOptimal

javac KthLargestElementInAnArrayBrute.java && java KthLargestElementInAnArrayBrute
javac KthLargestElementInAnArrayOptimal.java && java KthLargestElementInAnArrayOptimal

javac TopKFrequentElementsBrute.java && java TopKFrequentElementsBrute
javac TopKFrequentElementsOptimal.java && java TopKFrequentElementsOptimal
```
