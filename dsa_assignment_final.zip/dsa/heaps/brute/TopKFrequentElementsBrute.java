// ============================================================
// Problem  : Top K Frequent Elements
// Approach : Brute Force — count frequencies with HashMap,
//            then sort all entries by frequency descending,
//            pick top k.
// Time     : O(n log n)
// Space    : O(n)
// LeetCode : https://leetcode.com/problems/top-k-frequent-elements/
// ============================================================

import java.util.*;

public class TopKFrequentElementsBrute {

    public int[] topKFrequent(int[] nums, int k) {
        // step 1: count frequency of each number
        HashMap<Integer, Integer> freq = new HashMap<>();
        for (int num : nums) {
            freq.put(num, freq.getOrDefault(num, 0) + 1);
        }

        // step 2: sort entries by frequency in descending order
        List<Map.Entry<Integer, Integer>> entries = new ArrayList<>(freq.entrySet());
        entries.sort((a, b) -> b.getValue() - a.getValue()); // sort by value descending

        // step 3: collect top k elements
        int[] result = new int[k];
        for (int i = 0; i < k; i++) {
            result[i] = entries.get(i).getKey();
        }

        return result;
    }

    public static void main(String[] args) {
        TopKFrequentElementsBrute sol = new TopKFrequentElementsBrute();

        System.out.println(Arrays.toString(sol.topKFrequent(new int[]{1, 1, 1, 2, 2, 3}, 2))); // Expected: [1, 2]
        System.out.println(Arrays.toString(sol.topKFrequent(new int[]{1}, 1)));                 // Expected: [1]
    }
}
