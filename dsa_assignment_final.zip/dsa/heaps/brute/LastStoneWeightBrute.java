// ============================================================
// Problem  : Last Stone Weight
// Approach : Brute Force — sort on every iteration to find the two heaviest.
//            Simulate the smashing process step by step.
// Time     : O(n^2 log n) — sort called up to n times
// Space    : O(n) for the ArrayList
// LeetCode : https://leetcode.com/problems/last-stone-weight/
// ============================================================

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LastStoneWeightBrute {

    public int lastStoneWeight(int[] stones) {
        // use ArrayList so we can remove elements easily
        List<Integer> list = new ArrayList<>();
        for (int s : stones) list.add(s);

        while (list.size() > 1) {
            Collections.sort(list);                // sort ascending each time O(n log n)
            int n = list.size();

            int y = list.remove(n - 1);            // heaviest stone
            int x = list.remove(n - 2);            // second heaviest

            if (y != x) {
                list.add(y - x);                   // remainder added back
            }
            // if y == x, both destroyed — nothing added back
        }

        return list.isEmpty() ? 0 : list.get(0);  // 0 if all stones destroyed
    }

    public static void main(String[] args) {
        LastStoneWeightBrute sol = new LastStoneWeightBrute();

        System.out.println(sol.lastStoneWeight(new int[]{2, 7, 4, 1, 8, 1})); // Expected: 1
        System.out.println(sol.lastStoneWeight(new int[]{1}));                 // Expected: 1
    }
}
