// ============================================================
// Problem  : Kth Largest Element in an Array
// Approach : Brute Force — sort descending, return element at index k-1
// Time     : O(n log n)
// Space    : O(1) extra
// LeetCode : https://leetcode.com/problems/kth-largest-element-in-an-array/
// ============================================================

import java.util.Arrays;

public class KthLargestElementInAnArrayBrute {

    public int findKthLargest(int[] nums, int k) {
        Arrays.sort(nums); // sort ascending
        // k-th largest is at index (n - k) from the left
        return nums[nums.length - k];
    }

    public static void main(String[] args) {
        KthLargestElementInAnArrayBrute sol = new KthLargestElementInAnArrayBrute();

        System.out.println(sol.findKthLargest(new int[]{3, 2, 1, 5, 6, 4}, 2)); // Expected: 5
        System.out.println(sol.findKthLargest(new int[]{3, 2, 3, 1, 2, 4, 5, 5, 6}, 4)); // Expected: 4
    }
}
