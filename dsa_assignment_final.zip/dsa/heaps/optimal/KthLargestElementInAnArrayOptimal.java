// ============================================================
// Problem  : Kth Largest Element in an Array
// Approach : Optimal — min-heap of size k.
//            Keep exactly k largest elements seen so far.
//            The root (minimum of the heap) is the k-th largest overall.
//            Every offer/poll costs O(log k) — much better than O(log n).
// Time     : O(n log k)
// Space    : O(k)
// LeetCode : https://leetcode.com/problems/kth-largest-element-in-an-array/
// ============================================================

import java.util.PriorityQueue;

public class KthLargestElementInAnArrayOptimal {

    public int findKthLargest(int[] nums, int k) {
        // min-heap: smallest element always at the top
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();

        for (int num : nums) {
            minHeap.offer(num);        // add current number

            if (minHeap.size() > k) {
                minHeap.poll();        // evict smallest — heap stays size k
            }
        }

        // root = smallest among k largest = k-th largest overall
        return minHeap.peek();
    }

    public static void main(String[] args) {
        KthLargestElementInAnArrayOptimal sol = new KthLargestElementInAnArrayOptimal();

        System.out.println(sol.findKthLargest(new int[]{3, 2, 1, 5, 6, 4}, 2)); // Expected: 5
        System.out.println(sol.findKthLargest(new int[]{3, 2, 3, 1, 2, 4, 5, 5, 6}, 4)); // Expected: 4
    }
}
