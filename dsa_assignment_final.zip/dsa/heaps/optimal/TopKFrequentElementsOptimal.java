// ============================================================
// Problem  : Top K Frequent Elements
// Approach : Optimal — HashMap for frequencies + min-heap of size k.
//            Heap is keyed by frequency; we keep k most frequent.
//            Root of heap is the least frequent among top k.
// Time     : O(n log k)
// Space    : O(n + k)
// LeetCode : https://leetcode.com/problems/top-k-frequent-elements/
// ============================================================

import java.util.*;

public class TopKFrequentElementsOptimal {

    public int[] topKFrequent(int[] nums, int k) {
        // step 1: build frequency map
        HashMap<Integer, Integer> freq = new HashMap<>();
        for (int num : nums) {
            freq.put(num, freq.getOrDefault(num, 0) + 1);
        }

        // step 2: min-heap ordered by frequency (smallest freq at top)
        PriorityQueue<Integer> minHeap = new PriorityQueue<>(
            (a, b) -> freq.get(a) - freq.get(b) // compare by frequency
        );

        for (int num : freq.keySet()) {
            minHeap.offer(num);

            if (minHeap.size() > k) {
                minHeap.poll(); // remove least frequent — keep only top k
            }
        }

        // step 3: extract result (heap contains k most frequent numbers)
        int[] result = new int[k];
        for (int i = 0; i < k; i++) {
            result[i] = minHeap.poll();
        }

        return result;
    }

    public static void main(String[] args) {
        TopKFrequentElementsOptimal sol = new TopKFrequentElementsOptimal();

        System.out.println(Arrays.toString(sol.topKFrequent(new int[]{1, 1, 1, 2, 2, 3}, 2))); // Expected: [1, 2]
        System.out.println(Arrays.toString(sol.topKFrequent(new int[]{1}, 1)));                 // Expected: [1]
    }
}
