// ============================================================
// Problem  : Last Stone Weight
// Approach : Optimal — max-heap (negate values in Java's min-heap).
//            PriorityQueue in Java is a min-heap by default.
//            To simulate max-heap, store negative values.
// Time     : O(n log n)
// Space    : O(n)
// LeetCode : https://leetcode.com/problems/last-stone-weight/
// ============================================================

import java.util.Collections;
import java.util.PriorityQueue;

public class LastStoneWeightOptimal {

    public int lastStoneWeight(int[] stones) {
        // max-heap using reverse order comparator
        PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Collections.reverseOrder());

        for (int stone : stones) maxHeap.offer(stone);

        while (maxHeap.size() > 1) {
            int y = maxHeap.poll(); // heaviest — O(log n)
            int x = maxHeap.poll(); // second heaviest

            if (y != x) {
                maxHeap.offer(y - x); // push remainder back — O(log n)
            }
        }

        return maxHeap.isEmpty() ? 0 : maxHeap.poll();
    }

    public static void main(String[] args) {
        LastStoneWeightOptimal sol = new LastStoneWeightOptimal();

        System.out.println(sol.lastStoneWeight(new int[]{2, 7, 4, 1, 8, 1})); // Expected: 1
        System.out.println(sol.lastStoneWeight(new int[]{1}));                 // Expected: 1
    }
}
