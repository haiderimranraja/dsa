# Two Pointers

The two-pointer technique uses two indices that move toward or away from each other to reduce nested loops from O(n²) to O(n). Commonly applied on sorted arrays, palindrome checks, and area/container problems.

---

## Problem List

| # | Problem | Difficulty | LeetCode |
|---|---------|-----------|----------|
| 1 | Reverse String | Easy | [Link](https://leetcode.com/problems/reverse-string/) |
| 2 | Valid Palindrome | Easy | [Link](https://leetcode.com/problems/valid-palindrome/) |
| 3 | Container With Most Water | Medium | [Link](https://leetcode.com/problems/container-with-most-water/) |

---

## Approach

**Reverse String:** The brute force copies the array into a temp array filled in reverse — O(n) space. The optimal in-place swap uses two pointers starting at opposite ends, swapping and moving inward — O(1) space.

**Valid Palindrome:** The brute force builds a cleaned string (alphanumeric, lowercase) and compares it to its reverse — O(n) extra space. The optimal two-pointer approach works on the original string directly: skip non-alphanumeric characters from both ends and compare — O(1) space.

**Container With Most Water:** The brute force checks every pair of lines — O(n²). The optimal two-pointer approach starts from both ends. The key insight: always move the pointer at the shorter wall inward, because moving the taller side can only reduce width without guaranteeing a taller replacement. This ensures we never miss the optimal pair — O(n).

---

## Complexity Table

| Problem | Brute Time | Brute Space | Optimal Time | Optimal Space |
|---------|-----------|-------------|-------------|---------------|
| Reverse String | O(n) | O(n) | O(n) | O(1) |
| Valid Palindrome | O(n) | O(n) | O(n) | O(1) |
| Container With Most Water | O(n²) | O(1) | O(n) | O(1) |

---

## How to Run

```bash
javac ReverseStringBrute.java && java ReverseStringBrute
javac ReverseStringOptimal.java && java ReverseStringOptimal

javac ValidPalindromeBrute.java && java ValidPalindromeBrute
javac ValidPalindromeOptimal.java && java ValidPalindromeOptimal

javac ContainerWithMostWaterBrute.java && java ContainerWithMostWaterBrute
javac ContainerWithMostWaterOptimal.java && java ContainerWithMostWaterOptimal
```
