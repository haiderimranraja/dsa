// ============================================================
// Problem  : Container With Most Water
// Approach : Optimal — two pointers starting from both ends.
//            Always move the pointer with the SHORTER height inward.
//            Why? Moving the taller side can only reduce width
//            without guaranteeing a taller wall, so it can't help.
//            Moving the shorter side might find a taller wall.
// Time     : O(n)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/container-with-most-water/
// ============================================================

public class ContainerWithMostWaterOptimal {

    public int maxArea(int[] height) {
        int left     = 0;
        int right    = height.length - 1;
        int maxWater = 0;

        while (left < right) {
            // calculate current container's water
            int water = Math.min(height[left], height[right]) * (right - left);
            maxWater  = Math.max(maxWater, water);

            // move the pointer pointing to the shorter wall inward
            if (height[left] < height[right]) {
                left++;  // left is shorter, try to find a taller left wall
            } else {
                right--; // right is shorter (or equal), try to find a taller right wall
            }
        }

        return maxWater;
    }

    public static void main(String[] args) {
        ContainerWithMostWaterOptimal sol = new ContainerWithMostWaterOptimal();

        System.out.println(sol.maxArea(new int[]{1, 8, 6, 2, 5, 4, 8, 3, 7})); // Expected: 49
        System.out.println(sol.maxArea(new int[]{1, 1}));                       // Expected: 1
    }
}
