// ============================================================
// Problem  : Reverse String
// Approach : Optimal — two pointers from both ends, swap in-place
//            No extra space needed at all.
// Time     : O(n)
// Space    : O(1) — truly in-place
// LeetCode : https://leetcode.com/problems/reverse-string/
// ============================================================

public class ReverseStringOptimal {

    public void reverseString(char[] s) {
        int left  = 0;
        int right = s.length - 1;

        while (left < right) {
            // swap characters at left and right pointers
            char temp = s[left];
            s[left]   = s[right];
            s[right]  = temp;

            left++;  // move inward
            right--;
        }
    }

    public static void main(String[] args) {
        ReverseStringOptimal sol = new ReverseStringOptimal();

        char[] s1 = {'h', 'e', 'l', 'l', 'o'};
        sol.reverseString(s1);
        System.out.println(new String(s1)); // Expected: "olleh"

        char[] s2 = {'H', 'a', 'n', 'n', 'a', 'h'};
        sol.reverseString(s2);
        System.out.println(new String(s2)); // Expected: "hannaH"
    }
}
