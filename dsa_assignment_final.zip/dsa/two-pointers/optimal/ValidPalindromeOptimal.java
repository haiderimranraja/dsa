// ============================================================
// Problem  : Valid Palindrome
// Approach : Optimal — two pointers from both ends of original string.
//            Skip non-alphanumeric chars, compare in-place.
//            No extra string allocation needed.
// Time     : O(n)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/valid-palindrome/
// ============================================================

public class ValidPalindromeOptimal {

    public boolean isPalindrome(String s) {
        int left  = 0;
        int right = s.length() - 1;

        while (left < right) {
            // skip non-alphanumeric characters from left
            while (left < right && !Character.isLetterOrDigit(s.charAt(left))) {
                left++;
            }
            // skip non-alphanumeric characters from right
            while (left < right && !Character.isLetterOrDigit(s.charAt(right))) {
                right--;
            }

            // compare characters (case-insensitive)
            if (Character.toLowerCase(s.charAt(left)) != Character.toLowerCase(s.charAt(right))) {
                return false; // mismatch found
            }

            left++;
            right--;
        }

        return true; // no mismatch found
    }

    public static void main(String[] args) {
        ValidPalindromeOptimal sol = new ValidPalindromeOptimal();

        System.out.println(sol.isPalindrome("A man, a plan, a canal: Panama")); // true
        System.out.println(sol.isPalindrome("race a car"));                     // false
        System.out.println(sol.isPalindrome(" "));                              // true
    }
}
