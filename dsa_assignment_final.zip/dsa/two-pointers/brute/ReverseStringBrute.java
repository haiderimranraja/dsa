// ============================================================
// Problem  : Reverse String
// Approach : Brute Force — use an extra array, fill from the end
// Time     : O(n)
// Space    : O(n) extra space for temp array
// LeetCode : https://leetcode.com/problems/reverse-string/
// ============================================================

public class ReverseStringBrute {

    public void reverseString(char[] s) {
        char[] temp = new char[s.length]; // extra array

        // copy characters from s in reverse into temp
        for (int i = 0; i < s.length; i++) {
            temp[i] = s[s.length - 1 - i];
        }

        // copy back into original array
        for (int i = 0; i < s.length; i++) {
            s[i] = temp[i];
        }
    }

    public static void main(String[] args) {
        ReverseStringBrute sol = new ReverseStringBrute();

        char[] s1 = {'h', 'e', 'l', 'l', 'o'};
        sol.reverseString(s1);
        System.out.println(new String(s1)); // Expected: "olleh"

        char[] s2 = {'H', 'a', 'n', 'n', 'a', 'h'};
        sol.reverseString(s2);
        System.out.println(new String(s2)); // Expected: "hannaH"
    }
}
