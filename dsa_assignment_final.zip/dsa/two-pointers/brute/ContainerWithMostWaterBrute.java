// ============================================================
// Problem  : Container With Most Water
// Approach : Brute Force — check every pair of lines (i, j)
//            Area = min(height[i], height[j]) * (j - i)
// Time     : O(n^2)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/container-with-most-water/
// ============================================================

public class ContainerWithMostWaterBrute {

    public int maxArea(int[] height) {
        int maxWater = 0;

        for (int i = 0; i < height.length - 1; i++) {
            for (int j = i + 1; j < height.length; j++) {
                // water is limited by the shorter wall
                int water = Math.min(height[i], height[j]) * (j - i);
                maxWater = Math.max(maxWater, water);
            }
        }

        return maxWater;
    }

    public static void main(String[] args) {
        ContainerWithMostWaterBrute sol = new ContainerWithMostWaterBrute();

        System.out.println(sol.maxArea(new int[]{1, 8, 6, 2, 5, 4, 8, 3, 7})); // Expected: 49
        System.out.println(sol.maxArea(new int[]{1, 1}));                       // Expected: 1
    }
}
