// ============================================================
// Problem  : Valid Palindrome
// Approach : Brute Force — clean string (keep alphanumeric, lowercase),
//            then compare it to its reverse
// Time     : O(n)
// Space    : O(n) for the cleaned string and its reverse
// LeetCode : https://leetcode.com/problems/valid-palindrome/
// ============================================================

public class ValidPalindromeBrute {

    public boolean isPalindrome(String s) {
        // step 1: keep only alphanumeric characters, convert to lowercase
        StringBuilder cleaned = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (Character.isLetterOrDigit(c)) {
                cleaned.append(Character.toLowerCase(c));
            }
        }

        // step 2: compare cleaned string with its reverse
        String original = cleaned.toString();
        String reversed = cleaned.reverse().toString();

        return original.equals(reversed);
    }

    public static void main(String[] args) {
        ValidPalindromeBrute sol = new ValidPalindromeBrute();

        System.out.println(sol.isPalindrome("A man, a plan, a canal: Panama")); // true
        System.out.println(sol.isPalindrome("race a car"));                     // false
        System.out.println(sol.isPalindrome(" "));                              // true
    }
}
