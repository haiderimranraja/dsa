// ============================================================
// Problem  : Longest Common Prefix
// Approach : Brute Force — compare all pairs character by character
//            Use first string as reference, trim against each word
// Time     : O(n * m) where n = number of strings, m = min length
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/longest-common-prefix/
// ============================================================

public class LongestCommonPrefixBrute {

    public String longestCommonPrefix(String[] strs) {
        if (strs == null || strs.length == 0) return "";

        String prefix = strs[0]; // start with first string as candidate

        // compare prefix against every other string
        for (int i = 1; i < strs.length; i++) {
            // shrink prefix until it matches the start of strs[i]
            while (!strs[i].startsWith(prefix)) {
                prefix = prefix.substring(0, prefix.length() - 1); // chop last char
                if (prefix.isEmpty()) return ""; // no common prefix
            }
        }

        return prefix;
    }

    public static void main(String[] args) {
        LongestCommonPrefixBrute sol = new LongestCommonPrefixBrute();

        System.out.println(sol.longestCommonPrefix(new String[]{"flower", "flow", "flight"})); // Expected: "fl"
        System.out.println(sol.longestCommonPrefix(new String[]{"dog", "racecar", "car"}));    // Expected: ""
    }
}
