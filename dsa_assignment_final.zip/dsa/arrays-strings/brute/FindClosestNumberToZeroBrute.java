// ============================================================
// Problem  : Find Closest Number to Zero
// Approach : Brute Force — linear scan tracking minimum |x|
// Time     : O(n)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/find-closest-number-to-zero/
// ============================================================

public class FindClosestNumberToZeroBrute {

    public int findClosestNumber(int[] nums) {
        int closest = nums[0]; // assume first element is closest

        for (int i = 1; i < nums.length; i++) {
            // compare absolute values
            if (Math.abs(nums[i]) < Math.abs(closest)) {
                closest = nums[i];
            }
            // tie-break: if same distance, prefer positive number
            else if (Math.abs(nums[i]) == Math.abs(closest) && nums[i] > closest) {
                closest = nums[i];
            }
        }

        return closest;
    }

    public static void main(String[] args) {
        FindClosestNumberToZeroBrute sol = new FindClosestNumberToZeroBrute();

        int[] nums1 = {-4, -2, 1, 4, 8};
        System.out.println(sol.findClosestNumber(nums1)); // Expected: 1

        int[] nums2 = {2, -1, 1};
        System.out.println(sol.findClosestNumber(nums2)); // Expected: 1 (tie -> positive wins)
    }
}
