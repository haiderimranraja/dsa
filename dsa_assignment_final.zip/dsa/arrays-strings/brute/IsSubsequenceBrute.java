// ============================================================
// Problem  : Is Subsequence
// Approach : Brute Force — nested loop checking every character
//            of s against t in order
// Time     : O(n * m) where n = len(s), m = len(t)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/is-subsequence/
// ============================================================

public class IsSubsequenceBrute {

    public boolean isSubsequence(String s, String t) {
        int sIndex = 0; // pointer for s

        // walk through every character in t
        for (int tIndex = 0; tIndex < t.length(); tIndex++) {
            if (sIndex < s.length() && s.charAt(sIndex) == t.charAt(tIndex)) {
                sIndex++; // matched one character of s, move forward
            }
        }

        // if sIndex reached end of s, all characters were matched
        return sIndex == s.length();
    }

    public static void main(String[] args) {
        IsSubsequenceBrute sol = new IsSubsequenceBrute();

        System.out.println(sol.isSubsequence("ace", "abcde")); // Expected: true
        System.out.println(sol.isSubsequence("aec", "abcde")); // Expected: false
    }
}
