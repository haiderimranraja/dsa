// ============================================================
// Problem  : Summary Ranges
// Approach : Brute Force — check every pair to find range ends
// Time     : O(n)
// Space    : O(n) for result list
// LeetCode : https://leetcode.com/problems/summary-ranges/
// ============================================================

import java.util.ArrayList;
import java.util.List;

public class SummaryRangesBrute {

    public List<String> summaryRanges(int[] nums) {
        List<String> result = new ArrayList<>();

        if (nums.length == 0) return result;

        int i = 0;
        while (i < nums.length) {
            int start = nums[i]; // beginning of current range

            // walk forward while numbers are consecutive
            while (i + 1 < nums.length && nums[i + 1] == nums[i] + 1) {
                i++;
            }

            int end = nums[i]; // end of current range

            // format: "a->b" if range has >1 element, else just "a"
            if (start == end) {
                result.add(String.valueOf(start));
            } else {
                result.add(start + "->" + end);
            }

            i++; // move to next range
        }

        return result;
    }

    public static void main(String[] args) {
        SummaryRangesBrute sol = new SummaryRangesBrute();

        int[] nums1 = {0, 1, 2, 4, 5, 7};
        System.out.println(sol.summaryRanges(nums1)); // Expected: ["0->2","4->5","7"]

        int[] nums2 = {0, 2, 3, 4, 6, 8, 9};
        System.out.println(sol.summaryRanges(nums2)); // Expected: ["0","2->4","6","8->9"]
    }
}
