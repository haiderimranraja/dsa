// ============================================================
// Problem  : Best Time to Buy and Sell Stock
// Approach : Brute Force — try every pair (buy day, sell day)
//            where sell day > buy day
// Time     : O(n^2)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/best-time-to-buy-and-sell-stock/
// ============================================================

public class BestTimeToBuyAndSellStockBrute {

    public int maxProfit(int[] prices) {
        int maxProfit = 0;

        // outer loop = buy day
        for (int i = 0; i < prices.length - 1; i++) {
            // inner loop = sell day (must be after buy day)
            for (int j = i + 1; j < prices.length; j++) {
                int profit = prices[j] - prices[i]; // profit if buy at i, sell at j
                maxProfit = Math.max(maxProfit, profit);
            }
        }

        return maxProfit;
    }

    public static void main(String[] args) {
        BestTimeToBuyAndSellStockBrute sol = new BestTimeToBuyAndSellStockBrute();

        System.out.println(sol.maxProfit(new int[]{7, 1, 5, 3, 6, 4})); // Expected: 5
        System.out.println(sol.maxProfit(new int[]{7, 6, 4, 3, 1}));    // Expected: 0
    }
}
