# Arrays & Strings

Arrays are contiguous memory blocks allowing O(1) random access. String problems often reduce to array problems. Key techniques covered here: linear scan, two pointers, prefix logic, and sorting-based optimization.

---

## Problem List

| # | Problem | Difficulty | LeetCode |
|---|---------|-----------|----------|
| 1 | Find Closest Number to Zero | Easy | [Link](https://leetcode.com/problems/find-closest-number-to-zero/) |
| 2 | Is Subsequence | Easy | [Link](https://leetcode.com/problems/is-subsequence/) |
| 3 | Summary Ranges | Easy | [Link](https://leetcode.com/problems/summary-ranges/) |
| 4 | Longest Common Prefix | Easy | [Link](https://leetcode.com/problems/longest-common-prefix/) |
| 5 | Best Time to Buy & Sell Stock | Easy | [Link](https://leetcode.com/problems/best-time-to-buy-and-sell-stock/) |

---

## Approach

**Find Closest Number to Zero:** The brute force linearly scans tracking the minimum absolute value. The optimal approach is the same O(n) pass but handles the tie-breaking rule more cleanly — when two numbers have equal distance from zero, the positive one wins.

**Is Subsequence:** The brute force uses a single scan but the logic is identical to the optimal two-pointer approach. The true brute force mindset would be nested loops (O(n×m)); the optimal two-pointer solution advances i only on a match and always advances j, running in O(n+m).

**Summary Ranges:** The brute force checks every pair of indices to find gaps — O(n²). The optimal single-pass approach uses a `start` pointer: walk forward while numbers are consecutive, emit the range, then move to the next group. O(n).

**Longest Common Prefix:** Brute force trims the prefix character-by-character against each string. The optimal approach sorts the array lexicographically — only the first and last strings need to be compared, since all others fall in between. O(n log n) due to sort.

**Best Time to Buy and Sell Stock:** Brute force tries every pair (buy day, sell day) in O(n²). The optimal approach tracks the running minimum price seen so far; at each step, profit = today's price − min price. One pass, O(n).

---

## Complexity Table

| Problem | Brute Time | Brute Space | Optimal Time | Optimal Space |
|---------|-----------|-------------|-------------|---------------|
| Find Closest to Zero | O(n) | O(1) | O(n) | O(1) |
| Is Subsequence | O(n×m) | O(1) | O(n+m) | O(1) |
| Summary Ranges | O(n²) | O(n) | O(n) | O(n) |
| Longest Common Prefix | O(n×m) | O(1) | O(n log n) | O(1) |
| Buy & Sell Stock | O(n²) | O(1) | O(n) | O(1) |

---

## How to Run

```bash
# Compile
javac FindClosestNumberToZeroBrute.java
javac FindClosestNumberToZeroOptimal.java

# Run
java FindClosestNumberToZeroBrute
java FindClosestNumberToZeroOptimal

# Same pattern for all files:
javac IsSubsequenceBrute.java && java IsSubsequenceBrute
javac SummaryRangesBrute.java && java SummaryRangesBrute
javac LongestCommonPrefixBrute.java && java LongestCommonPrefixBrute
javac BestTimeToBuyAndSellStockBrute.java && java BestTimeToBuyAndSellStockBrute
```
