// ============================================================
// Problem  : Longest Common Prefix
// Approach : Optimal — sort lexicographically, then only compare
//            first and last strings. All others fall in between,
//            so common prefix of first & last covers all.
// Time     : O(n log n) for sort + O(m) comparison = O(n log n)
// Space    : O(1) extra (sort is in-place)
// LeetCode : https://leetcode.com/problems/longest-common-prefix/
// ============================================================

import java.util.Arrays;

public class LongestCommonPrefixOptimal {

    public String longestCommonPrefix(String[] strs) {
        if (strs == null || strs.length == 0) return "";

        // sort so lexicographic extremes are at index 0 and n-1
        Arrays.sort(strs);

        String first = strs[0];
        String last  = strs[strs.length - 1];

        int i = 0;
        // compare character by character between first and last only
        while (i < first.length() && i < last.length()
                && first.charAt(i) == last.charAt(i)) {
            i++;
        }

        return first.substring(0, i); // common prefix
    }

    public static void main(String[] args) {
        LongestCommonPrefixOptimal sol = new LongestCommonPrefixOptimal();

        System.out.println(sol.longestCommonPrefix(new String[]{"flower", "flow", "flight"})); // Expected: "fl"
        System.out.println(sol.longestCommonPrefix(new String[]{"dog", "racecar", "car"}));    // Expected: ""
    }
}
