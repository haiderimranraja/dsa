// ============================================================
// Problem  : Best Time to Buy and Sell Stock
// Approach : Optimal — track running minimum price seen so far.
//            At each day, profit = price - minPrice seen so far.
//            One pass is enough.
// Time     : O(n)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/best-time-to-buy-and-sell-stock/
// ============================================================

public class BestTimeToBuyAndSellStockOptimal {

    public int maxProfit(int[] prices) {
        int minPrice  = Integer.MAX_VALUE; // cheapest buy price seen so far
        int maxProfit = 0;

        for (int price : prices) {
            if (price < minPrice) {
                minPrice = price; // found a cheaper day to buy
            } else {
                // selling today: profit = today's price - best buy so far
                maxProfit = Math.max(maxProfit, price - minPrice);
            }
        }

        return maxProfit;
    }

    public static void main(String[] args) {
        BestTimeToBuyAndSellStockOptimal sol = new BestTimeToBuyAndSellStockOptimal();

        System.out.println(sol.maxProfit(new int[]{7, 1, 5, 3, 6, 4})); // Expected: 5
        System.out.println(sol.maxProfit(new int[]{7, 6, 4, 3, 1}));    // Expected: 0
    }
}
