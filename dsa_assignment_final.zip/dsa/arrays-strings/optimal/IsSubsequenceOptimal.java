// ============================================================
// Problem  : Is Subsequence
// Approach : Optimal — two pointers moving independently
//            i advances only when characters match
//            j always advances through t
// Time     : O(n + m)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/is-subsequence/
// ============================================================

public class IsSubsequenceOptimal {

    public boolean isSubsequence(String s, String t) {
        int i = 0; // pointer for s
        int j = 0; // pointer for t

        // advance both pointers; i only moves on a match
        while (i < s.length() && j < t.length()) {
            if (s.charAt(i) == t.charAt(j)) {
                i++; // matched -> move s pointer
            }
            j++; // always move t pointer
        }

        return i == s.length(); // true if all of s was matched
    }

    public static void main(String[] args) {
        IsSubsequenceOptimal sol = new IsSubsequenceOptimal();

        System.out.println(sol.isSubsequence("ace", "abcde")); // Expected: true
        System.out.println(sol.isSubsequence("aec", "abcde")); // Expected: false
    }
}
