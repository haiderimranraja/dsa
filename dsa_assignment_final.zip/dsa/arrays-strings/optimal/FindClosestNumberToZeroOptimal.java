// ============================================================
// Problem  : Find Closest Number to Zero
// Approach : Optimal — same O(n) scan but cleaner tie-break logic
//            Key insight: if |x| == |closest| and x > 0, update.
//            This is already O(n) optimal for unsorted input.
// Time     : O(n)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/find-closest-number-to-zero/
// ============================================================

public class FindClosestNumberToZeroOptimal {

    public int findClosestNumber(int[] nums) {
        int closest = nums[0];

        for (int num : nums) {
            // update if strictly closer, OR equally close but num is positive
            if (Math.abs(num) < Math.abs(closest)
                    || (Math.abs(num) == Math.abs(closest) && num > closest)) {
                closest = num;
            }
        }

        return closest;
    }

    public static void main(String[] args) {
        FindClosestNumberToZeroOptimal sol = new FindClosestNumberToZeroOptimal();

        int[] nums1 = {-4, -2, 1, 4, 8};
        System.out.println(sol.findClosestNumber(nums1)); // Expected: 1

        int[] nums2 = {2, -1, 1};
        System.out.println(sol.findClosestNumber(nums2)); // Expected: 1
    }
}
