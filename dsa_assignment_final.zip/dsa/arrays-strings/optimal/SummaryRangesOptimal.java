// ============================================================
// Problem  : Summary Ranges
// Approach : Optimal — single pass with a start pointer
//            Record start, advance until gap, then emit range
// Time     : O(n)
// Space    : O(n) for result (unavoidable for output)
// LeetCode : https://leetcode.com/problems/summary-ranges/
// ============================================================

import java.util.ArrayList;
import java.util.List;

public class SummaryRangesOptimal {

    public List<String> summaryRanges(int[] nums) {
        List<String> result = new ArrayList<>();
        int n = nums.length;
        int i = 0;

        while (i < n) {
            int start = i; // remember where the range begins

            // advance while the sequence is consecutive
            while (i + 1 < n && nums[i + 1] == nums[i] + 1) {
                i++;
            }

            // build the range string in one step
            if (nums[start] == nums[i]) {
                result.add(String.valueOf(nums[start]));
            } else {
                result.add(nums[start] + "->" + nums[i]);
            }

            i++;
        }

        return result;
    }

    public static void main(String[] args) {
        SummaryRangesOptimal sol = new SummaryRangesOptimal();

        int[] nums1 = {0, 1, 2, 4, 5, 7};
        System.out.println(sol.summaryRanges(nums1)); // Expected: ["0->2","4->5","7"]

        int[] nums2 = {0, 2, 3, 4, 6, 8, 9};
        System.out.println(sol.summaryRanges(nums2)); // Expected: ["0","2->4","6","8->9"]
    }
}
