# DSA — Data Structures & Algorithms

Graded programming assignment for the Data Structures & Algorithms course.  
All solutions are written in **Java**. Each problem has two implementations: a **Brute Force** approach to establish correctness, and an **Optimal** approach to improve time/space complexity.

---

## Repository Structure

```
dsa/
├── arrays-strings/
│   ├── brute/
│   └── optimal/
├── hash-tables/
│   ├── brute/
│   └── optimal/
├── two-pointers/
│   ├── brute/
│   └── optimal/
├── binary-trees/
│   ├── brute/
│   └── optimal/
├── linked-lists/
│   ├── brute/
│   └── optimal/
└── heaps/
    ├── brute/
    └── optimal/
```

---

## Topic Index

| Topic | Problems | README |
|-------|---------|--------|
| [Arrays & Strings](./arrays-strings/) | Find Closest to Zero, Is Subsequence, Summary Ranges, Longest Common Prefix, Buy & Sell Stock | [README](./arrays-strings/README.md) |
| [Hash Tables](./hash-tables/) | Contains Duplicate, Two Sum, Max Balloons, Valid Anagram, Group Anagrams | [README](./hash-tables/README.md) |
| [Two Pointers](./two-pointers/) | Reverse String, Valid Palindrome, Container With Most Water | [README](./two-pointers/README.md) |
| [Binary Trees](./binary-trees/) | Invert Tree, Max Depth, Kth Smallest, Diameter, Validate BST, Trie, Min Abs Diff | [README](./binary-trees/README.md) |
| [Linked Lists](./linked-lists/) | Remove Duplicates, Linked List Cycle, Merge Two Sorted Lists | [README](./linked-lists/README.md) |
| [Heaps](./heaps/) | Last Stone Weight, Kth Largest Element, Top K Frequent Elements | [README](./heaps/README.md) |

---

## Key Concepts Demonstrated

- **Brute → Optimal:** Every problem shows the O(n²) or naive approach first, then refactors to an optimal solution using the right data structure.
- **Hash Maps** collapse O(n²) pair searches into O(n) single-pass lookups.
- **Two Pointers** eliminate nested loops on sorted/linear structures.
- **Heaps** solve "top K" problems in O(n log k) vs O(n log n) sorting.
- **DFS with bounds** validates tree invariants without extra space.
- **Floyd's Algorithm** detects cycles in O(1) space.

---

## How to Run Any File

```bash
# Navigate to the folder containing the file
cd arrays-strings/brute

# Compile
javac FindClosestNumberToZeroBrute.java

# Run
java FindClosestNumberToZeroBrute
```

Java 8 or above required. No external dependencies.
