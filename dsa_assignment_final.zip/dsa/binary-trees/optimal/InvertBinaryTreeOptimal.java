// ============================================================
// Problem  : Invert Binary Tree
// Approach : Optimal — recursive DFS. Elegantly swap children
//            at each node and recurse. Same O(n) complexity but
//            cleaner and uses call stack instead of explicit queue.
// Time     : O(n)
// Space    : O(h) where h = tree height (call stack)
// LeetCode : https://leetcode.com/problems/invert-binary-tree/
// ============================================================

public class InvertBinaryTreeOptimal {

    static class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val   = val;
            this.left  = left;
            this.right = right;
        }
    }

    public TreeNode invertTree(TreeNode root) {
        if (root == null) return null; // base case: empty tree

        // recursively invert left and right subtrees first
        TreeNode left  = invertTree(root.left);
        TreeNode right = invertTree(root.right);

        // then swap them at current node
        root.left  = right;
        root.right = left;

        return root;
    }

    static void inorder(TreeNode node) {
        if (node == null) return;
        inorder(node.left);
        System.out.print(node.val + " ");
        inorder(node.right);
    }

    public static void main(String[] args) {
        InvertBinaryTreeOptimal sol = new InvertBinaryTreeOptimal();

        TreeNode root = new TreeNode(4,
            new TreeNode(2, new TreeNode(1), new TreeNode(3)),
            new TreeNode(7, new TreeNode(6), new TreeNode(9))
        );

        sol.invertTree(root);
        inorder(root); // Expected: 9 7 6 4 3 2 1
        System.out.println();
    }
}
