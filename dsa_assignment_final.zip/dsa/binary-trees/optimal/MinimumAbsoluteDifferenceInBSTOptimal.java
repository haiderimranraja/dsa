// ============================================================
// Problem  : Minimum Absolute Difference in BST
// Approach : Optimal — inorder traversal with a 'prev' pointer.
//            Since BST inorder is sorted, minimum diff is always
//            between adjacent nodes. Track previous node as we go.
// Time     : O(n)
// Space    : O(h) call stack
// LeetCode : https://leetcode.com/problems/minimum-absolute-difference-in-bst/
// ============================================================

public class MinimumAbsoluteDifferenceInBSTOptimal {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    private int minDiff = Integer.MAX_VALUE;
    private Integer prev = null; // previous node value in inorder traversal

    private void inorder(TreeNode node) {
        if (node == null) return;

        inorder(node.left); // go left first (smaller values)

        // compare current node with previous node in inorder
        if (prev != null) {
            minDiff = Math.min(minDiff, node.val - prev); // guaranteed non-negative (sorted)
        }
        prev = node.val; // update prev to current

        inorder(node.right); // then go right (larger values)
    }

    public int getMinimumDifference(TreeNode root) {
        inorder(root);
        return minDiff;
    }

    public static void main(String[] args) {
        MinimumAbsoluteDifferenceInBSTOptimal sol = new MinimumAbsoluteDifferenceInBSTOptimal();

        TreeNode root = new TreeNode(4,
            new TreeNode(2, new TreeNode(1), new TreeNode(3)),
            new TreeNode(6)
        );

        System.out.println(sol.getMinimumDifference(root)); // Expected: 1
    }
}
