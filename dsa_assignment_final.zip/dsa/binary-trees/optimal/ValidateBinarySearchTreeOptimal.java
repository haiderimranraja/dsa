// ============================================================
// Problem  : Validate Binary Search Tree
// Approach : Optimal — DFS with min/max bounds.
//            Each node must satisfy: min < node.val < max
//            Left subtree: max bound tightens to current node value
//            Right subtree: min bound tightens to current node value
// Time     : O(n)
// Space    : O(h) call stack
// LeetCode : https://leetcode.com/problems/validate-binary-search-tree/
// ============================================================

public class ValidateBinarySearchTreeOptimal {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    private boolean validate(TreeNode node, long min, long max) {
        if (node == null) return true; // empty subtree is valid

        // current node must be strictly within (min, max)
        if (node.val <= min || node.val >= max) return false;

        // left child: all values must be < node.val (so max becomes node.val)
        // right child: all values must be > node.val (so min becomes node.val)
        return validate(node.left, min, node.val)
            && validate(node.right, node.val, max);
    }

    public boolean isValidBST(TreeNode root) {
        // use Long.MIN_VALUE and Long.MAX_VALUE to handle Integer edge cases
        return validate(root, Long.MIN_VALUE, Long.MAX_VALUE);
    }

    public static void main(String[] args) {
        ValidateBinarySearchTreeOptimal sol = new ValidateBinarySearchTreeOptimal();

        TreeNode valid = new TreeNode(2, new TreeNode(1), new TreeNode(3));
        System.out.println(sol.isValidBST(valid)); // Expected: true

        TreeNode invalid = new TreeNode(5,
            new TreeNode(1),
            new TreeNode(4, new TreeNode(3), new TreeNode(6))
        );
        System.out.println(sol.isValidBST(invalid)); // Expected: false
    }
}
