// ============================================================
// Problem  : Kth Smallest Element in a BST
// Approach : Optimal — iterative inorder using explicit stack.
//            Stop as soon as we've visited k nodes.
//            No need to traverse the entire tree.
// Time     : O(k) — only visit k nodes
// Space    : O(h) — stack depth = tree height
// LeetCode : https://leetcode.com/problems/kth-smallest-element-in-a-bst/
// ============================================================

import java.util.Stack;

public class KthSmallestElementInABSTOptimal {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    public int kthSmallest(TreeNode root, int k) {
        Stack<TreeNode> stack = new Stack<>();
        TreeNode curr = root;

        while (curr != null || !stack.isEmpty()) {
            // go as far left as possible (smallest values)
            while (curr != null) {
                stack.push(curr);
                curr = curr.left;
            }

            // process node
            curr = stack.pop();
            k--;                      // we've visited one more node in order
            if (k == 0) return curr.val; // found k-th smallest — stop early!

            curr = curr.right; // move to right subtree
        }

        return -1; // never reached if k is valid
    }

    public static void main(String[] args) {
        TreeNode root = new TreeNode(3,
            new TreeNode(1, null, new TreeNode(2)),
            new TreeNode(4)
        );

        KthSmallestElementInABSTOptimal sol = new KthSmallestElementInABSTOptimal();
        System.out.println(sol.kthSmallest(root, 1)); // Expected: 1
        System.out.println(sol.kthSmallest(root, 3)); // Expected: 3
    }
}
