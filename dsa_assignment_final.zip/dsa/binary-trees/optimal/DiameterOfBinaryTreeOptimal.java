// ============================================================
// Problem  : Diameter of Binary Tree
// Approach : Optimal — single DFS pass. Each recursive call returns
//            the HEIGHT of the subtree, and updates a global max
//            diameter along the way. No repeated height computations.
// Time     : O(n)
// Space    : O(h) call stack
// LeetCode : https://leetcode.com/problems/diameter-of-binary-tree/
// ============================================================

public class DiameterOfBinaryTreeOptimal {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    private int maxDiameter = 0; // global variable to track best diameter seen

    private int dfs(TreeNode node) {
        if (node == null) return 0; // null subtree has height 0

        int leftHeight  = dfs(node.left);  // height of left subtree
        int rightHeight = dfs(node.right); // height of right subtree

        // diameter at this node = edges on left path + edges on right path
        maxDiameter = Math.max(maxDiameter, leftHeight + rightHeight);

        // return height of this subtree to parent
        return 1 + Math.max(leftHeight, rightHeight);
    }

    public int diameterOfBinaryTree(TreeNode root) {
        dfs(root);
        return maxDiameter;
    }

    public static void main(String[] args) {
        DiameterOfBinaryTreeOptimal sol = new DiameterOfBinaryTreeOptimal();

        TreeNode root = new TreeNode(1,
            new TreeNode(2, new TreeNode(4), new TreeNode(5)),
            new TreeNode(3)
        );

        System.out.println(sol.diameterOfBinaryTree(root)); // Expected: 3
    }
}
