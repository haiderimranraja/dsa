// ============================================================
// Problem  : Implement Trie (Prefix Tree)
// Approach : Optimal — each TrieNode has a children array of size 26
//            (one slot per lowercase letter) and an isEnd flag.
//            insert/search/startsWith all run in O(L) where L = word length.
// Time     : O(L) per operation
// Space    : O(n * L * 26) — worst case, all nodes fully branched
// LeetCode : https://leetcode.com/problems/implement-trie-prefix-tree/
// ============================================================

public class ImplementTrieOptimal {

    static class TrieNode {
        TrieNode[] children = new TrieNode[26]; // one child per letter a-z
        boolean isEnd = false;                  // marks end of a complete word
    }

    static class Trie {
        private final TrieNode root = new TrieNode();

        public void insert(String word) {
            TrieNode node = root;
            for (char c : word.toCharArray()) {
                int idx = c - 'a'; // 'a'=0, 'b'=1, ..., 'z'=25
                if (node.children[idx] == null) {
                    node.children[idx] = new TrieNode(); // create node if missing
                }
                node = node.children[idx]; // move down the trie
            }
            node.isEnd = true; // mark end of this word
        }

        public boolean search(String word) {
            TrieNode node = findNode(word);
            return node != null && node.isEnd; // must exist AND be a complete word
        }

        public boolean startsWith(String prefix) {
            return findNode(prefix) != null; // just need the path to exist
        }

        // helper: traverse trie following characters of 'str'
        private TrieNode findNode(String str) {
            TrieNode node = root;
            for (char c : str.toCharArray()) {
                int idx = c - 'a';
                if (node.children[idx] == null) return null; // path doesn't exist
                node = node.children[idx];
            }
            return node;
        }
    }

    public static void main(String[] args) {
        Trie trie = new Trie();

        trie.insert("apple");
        System.out.println(trie.search("apple"));    // Expected: true
        System.out.println(trie.search("app"));      // Expected: false
        System.out.println(trie.startsWith("app"));  // Expected: true

        trie.insert("app");
        System.out.println(trie.search("app"));      // Expected: true
    }
}
