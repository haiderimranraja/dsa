// ============================================================
// Problem  : Maximum Depth of Binary Tree
// Approach : Optimal — recursive DFS.
//            depth = 1 + max(leftDepth, rightDepth)
//            Concise and elegant; uses call stack naturally.
// Time     : O(n)
// Space    : O(h) where h = height (best case O(log n), worst O(n))
// LeetCode : https://leetcode.com/problems/maximum-depth-of-binary-tree/
// ============================================================

public class MaximumDepthOfBinaryTreeOptimal {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    public int maxDepth(TreeNode root) {
        if (root == null) return 0; // base case: empty subtree contributes 0

        int leftDepth  = maxDepth(root.left);  // depth of left subtree
        int rightDepth = maxDepth(root.right); // depth of right subtree

        return 1 + Math.max(leftDepth, rightDepth); // current node adds 1
    }

    public static void main(String[] args) {
        MaximumDepthOfBinaryTreeOptimal sol = new MaximumDepthOfBinaryTreeOptimal();

        TreeNode root = new TreeNode(3,
            new TreeNode(9),
            new TreeNode(20, new TreeNode(15), new TreeNode(7))
        );

        System.out.println(sol.maxDepth(root)); // Expected: 3
        System.out.println(sol.maxDepth(new TreeNode(1, null, new TreeNode(2)))); // Expected: 2
    }
}
