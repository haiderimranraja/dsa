# Binary Trees

Binary trees underpin search, sorting, and hierarchical data. Key traversal strategies are DFS (inorder, preorder, postorder) and BFS (level-order). BST invariant: left < root < right. Tries are prefix trees used for autocomplete and spell-check.

---

## Problem List

| # | Problem | Difficulty | LeetCode |
|---|---------|-----------|----------|
| 1 | Invert Binary Tree | Easy | [Link](https://leetcode.com/problems/invert-binary-tree/) |
| 2 | Maximum Depth of Binary Tree | Easy | [Link](https://leetcode.com/problems/maximum-depth-of-binary-tree/) |
| 3 | Kth Smallest Element in a BST | Medium | [Link](https://leetcode.com/problems/kth-smallest-element-in-a-bst/) |
| 4 | Diameter of Binary Tree | Easy | [Link](https://leetcode.com/problems/diameter-of-binary-tree/) |
| 5 | Validate Binary Search Tree | Medium | [Link](https://leetcode.com/problems/validate-binary-search-tree/) |
| 6 | Implement Trie (Prefix Tree) | Medium | [Link](https://leetcode.com/problems/implement-trie-prefix-tree/) |
| 7 | Minimum Absolute Difference in BST | Easy | [Link](https://leetcode.com/problems/minimum-absolute-difference-in-bst/) |

---

## Approach

**Invert Binary Tree:** The brute force uses iterative BFS with a queue, swapping children at each level. The optimal recursive DFS is more elegant: invert left and right subtrees first, then swap them at the current node — same O(n) but cleaner code.

**Maximum Depth:** The brute force BFS counts levels using a queue. The optimal recursive DFS derives depth as `1 + max(leftDepth, rightDepth)` — leverages the call stack naturally, O(n) time, O(h) space.

**Kth Smallest in BST:** The brute force collects all values via inorder traversal into a list, then returns index k-1 — O(n) time and space. The optimal iterative inorder with an explicit stack stops as soon as k nodes have been visited — O(k) time, O(h) space.

**Diameter of Binary Tree:** The brute force computes height of left and right subtrees separately for every node — O(n²) due to repeated work. The optimal single DFS pass computes height bottom-up and updates the global max diameter along the way — O(n).

**Validate BST:** The brute force collects inorder values and checks they are strictly ascending — O(n) time, O(n) space. The optimal DFS with min/max bounds validates each node directly: every node must satisfy `min < val < max`, with bounds tightening at each recursive call — O(n) time, O(h) space.

**Implement Trie:** The brute force stores all words in an ArrayList — insert is O(1) but search and startsWith are O(n×k). The optimal TrieNode structure with a 26-element children array achieves O(L) for all operations where L is word length.

**Minimum Absolute Difference in BST:** The brute force collects all values then compares all pairs — O(n²). The optimal approach uses inorder traversal with a `prev` pointer: since BST inorder is always sorted, the minimum difference always occurs between adjacent nodes — O(n).

---

## Complexity Table

| Problem | Brute Time | Brute Space | Optimal Time | Optimal Space |
|---------|-----------|-------------|-------------|---------------|
| Invert Binary Tree | O(n) | O(n) | O(n) | O(h) |
| Maximum Depth | O(n) | O(n) | O(n) | O(h) |
| Kth Smallest in BST | O(n) | O(n) | O(k) | O(h) |
| Diameter | O(n²) | O(h) | O(n) | O(h) |
| Validate BST | O(n) | O(n) | O(n) | O(h) |
| Implement Trie | O(n×k) per query | O(n×k) | O(L) per op | O(n×L×26) |
| Min Abs Diff in BST | O(n²) | O(n) | O(n) | O(h) |

*h = tree height; L = word length*

---

## How to Run

```bash
javac InvertBinaryTreeBrute.java && java InvertBinaryTreeBrute
javac InvertBinaryTreeOptimal.java && java InvertBinaryTreeOptimal

javac MaximumDepthOfBinaryTreeBrute.java && java MaximumDepthOfBinaryTreeBrute
javac KthSmallestElementInABSTBrute.java && java KthSmallestElementInABSTBrute
javac DiameterOfBinaryTreeBrute.java && java DiameterOfBinaryTreeBrute
javac ValidateBinarySearchTreeBrute.java && java ValidateBinarySearchTreeBrute
javac ImplementTrieBrute.java && java ImplementTrieBrute
javac MinimumAbsoluteDifferenceInBSTBrute.java && java MinimumAbsoluteDifferenceInBSTBrute
```
