// ============================================================
// Problem  : Maximum Depth of Binary Tree
// Approach : Brute Force — BFS level-order traversal.
//            Count levels using a queue and level counter.
// Time     : O(n)
// Space    : O(n) — queue can hold entire level
// LeetCode : https://leetcode.com/problems/maximum-depth-of-binary-tree/
// ============================================================

import java.util.LinkedList;
import java.util.Queue;

public class MaximumDepthOfBinaryTreeBrute {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    public int maxDepth(TreeNode root) {
        if (root == null) return 0;

        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        int depth = 0;

        while (!queue.isEmpty()) {
            int levelSize = queue.size(); // number of nodes at current level
            depth++;                     // entering a new level

            // process all nodes at this level
            for (int i = 0; i < levelSize; i++) {
                TreeNode node = queue.poll();
                if (node.left  != null) queue.offer(node.left);
                if (node.right != null) queue.offer(node.right);
            }
        }

        return depth;
    }

    public static void main(String[] args) {
        MaximumDepthOfBinaryTreeBrute sol = new MaximumDepthOfBinaryTreeBrute();

        //     3
        //    / \
        //   9  20
        //     /  \
        //    15   7
        TreeNode root = new TreeNode(3,
            new TreeNode(9),
            new TreeNode(20, new TreeNode(15), new TreeNode(7))
        );

        System.out.println(sol.maxDepth(root)); // Expected: 3
        System.out.println(sol.maxDepth(new TreeNode(1, null, new TreeNode(2)))); // Expected: 2
    }
}
