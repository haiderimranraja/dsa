// ============================================================
// Problem  : Diameter of Binary Tree
// Approach : Brute Force — for each node, compute height of left
//            and right subtrees separately. Diameter through a node
//            = leftHeight + rightHeight. O(n^2) due to repeated work.
// Time     : O(n^2)
// Space    : O(h) call stack
// LeetCode : https://leetcode.com/problems/diameter-of-binary-tree/
// ============================================================

public class DiameterOfBinaryTreeBrute {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    // helper: returns height of a subtree
    private int height(TreeNode node) {
        if (node == null) return 0;
        return 1 + Math.max(height(node.left), height(node.right));
    }

    public int diameterOfBinaryTree(TreeNode root) {
        if (root == null) return 0;

        // diameter passing through current root = left height + right height
        int throughRoot = height(root.left) + height(root.right);

        // diameter might also be entirely in left or right subtree
        int leftDiam  = diameterOfBinaryTree(root.left);
        int rightDiam = diameterOfBinaryTree(root.right);

        return Math.max(throughRoot, Math.max(leftDiam, rightDiam));
    }

    public static void main(String[] args) {
        DiameterOfBinaryTreeBrute sol = new DiameterOfBinaryTreeBrute();

        //     1
        //    / \
        //   2   3
        //  / \
        // 4   5
        TreeNode root = new TreeNode(1,
            new TreeNode(2, new TreeNode(4), new TreeNode(5)),
            new TreeNode(3)
        );

        System.out.println(sol.diameterOfBinaryTree(root)); // Expected: 3
    }
}
