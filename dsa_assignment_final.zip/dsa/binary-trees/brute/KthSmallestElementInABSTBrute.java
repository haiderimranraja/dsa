// ============================================================
// Problem  : Kth Smallest Element in a BST
// Approach : Brute Force — collect all values via inorder traversal
//            into a list (BST inorder = sorted), then return index k-1
// Time     : O(n)
// Space    : O(n) for the list
// LeetCode : https://leetcode.com/problems/kth-smallest-element-in-a-bst/
// ============================================================

import java.util.ArrayList;
import java.util.List;

public class KthSmallestElementInABSTBrute {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    private List<Integer> values = new ArrayList<>();

    // inorder: left -> root -> right gives sorted order in BST
    private void inorder(TreeNode node) {
        if (node == null) return;
        inorder(node.left);
        values.add(node.val);
        inorder(node.right);
    }

    public int kthSmallest(TreeNode root, int k) {
        inorder(root);
        return values.get(k - 1); // k is 1-indexed, list is 0-indexed
    }

    public static void main(String[] args) {
        //     3
        //    / \
        //   1   4
        //    \
        //     2
        TreeNode root = new TreeNode(3,
            new TreeNode(1, null, new TreeNode(2)),
            new TreeNode(4)
        );

        KthSmallestElementInABSTBrute sol = new KthSmallestElementInABSTBrute();
        System.out.println(sol.kthSmallest(root, 1)); // Expected: 1
    }
}
