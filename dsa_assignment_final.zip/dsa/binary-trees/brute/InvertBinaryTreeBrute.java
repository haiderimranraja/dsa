// ============================================================
// Problem  : Invert Binary Tree
// Approach : Brute Force — iterative BFS using a Queue.
//            Level by level, swap left and right children.
// Time     : O(n) — visit every node once
// Space    : O(n) — queue holds up to n/2 nodes at one level
// LeetCode : https://leetcode.com/problems/invert-binary-tree/
// ============================================================

import java.util.LinkedList;
import java.util.Queue;

public class InvertBinaryTreeBrute {

    // Definition for a binary tree node
    static class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val   = val;
            this.left  = left;
            this.right = right;
        }
    }

    public TreeNode invertTree(TreeNode root) {
        if (root == null) return null;

        Queue<TreeNode> queue = new LinkedList<>();
        queue.offer(root);

        while (!queue.isEmpty()) {
            TreeNode node = queue.poll();

            // swap left and right children
            TreeNode temp  = node.left;
            node.left      = node.right;
            node.right     = temp;

            // add children to queue for processing
            if (node.left  != null) queue.offer(node.left);
            if (node.right != null) queue.offer(node.right);
        }

        return root;
    }

    // helper: print inorder traversal to verify result
    static void inorder(TreeNode node) {
        if (node == null) return;
        inorder(node.left);
        System.out.print(node.val + " ");
        inorder(node.right);
    }

    public static void main(String[] args) {
        InvertBinaryTreeBrute sol = new InvertBinaryTreeBrute();

        //     4
        //    / \
        //   2   7
        //  / \ / \
        // 1  3 6  9
        TreeNode root = new TreeNode(4,
            new TreeNode(2, new TreeNode(1), new TreeNode(3)),
            new TreeNode(7, new TreeNode(6), new TreeNode(9))
        );

        sol.invertTree(root);
        inorder(root); // Expected inorder of inverted: 9 7 6 4 3 2 1
        System.out.println();
    }
}
