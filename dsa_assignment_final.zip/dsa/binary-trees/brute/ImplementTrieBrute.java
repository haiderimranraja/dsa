// ============================================================
// Problem  : Implement Trie (Prefix Tree)
// Approach : Brute Force — store all inserted words in an ArrayList.
//            search() checks if the exact word exists.
//            startsWith() checks if any stored word begins with prefix.
// Time     : insert O(1), search O(n*k), startsWith O(n*k)
//            where n = number of words, k = average word length
// Space    : O(n * k)
// LeetCode : https://leetcode.com/problems/implement-trie-prefix-tree/
// ============================================================

import java.util.ArrayList;
import java.util.List;

public class ImplementTrieBrute {

    static class Trie {
        private List<String> words = new ArrayList<>();

        public void insert(String word) {
            words.add(word); // just store the whole word
        }

        public boolean search(String word) {
            return words.contains(word); // O(n) linear scan
        }

        public boolean startsWith(String prefix) {
            for (String w : words) {
                if (w.startsWith(prefix)) return true; // found a word with this prefix
            }
            return false;
        }
    }

    public static void main(String[] args) {
        Trie trie = new Trie();

        trie.insert("apple");
        System.out.println(trie.search("apple"));    // Expected: true
        System.out.println(trie.search("app"));      // Expected: false
        System.out.println(trie.startsWith("app"));  // Expected: true

        trie.insert("app");
        System.out.println(trie.search("app"));      // Expected: true
    }
}
