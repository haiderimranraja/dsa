// ============================================================
// Problem  : Minimum Absolute Difference in BST
// Approach : Brute Force — collect all values via inorder into a list,
//            then compare all pairs to find minimum difference
// Time     : O(n^2) for comparing all pairs (after O(n) traversal)
// Space    : O(n) for the list
// LeetCode : https://leetcode.com/problems/minimum-absolute-difference-in-bst/
// ============================================================

import java.util.ArrayList;
import java.util.List;

public class MinimumAbsoluteDifferenceInBSTBrute {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    private List<Integer> values = new ArrayList<>();

    private void inorder(TreeNode node) {
        if (node == null) return;
        inorder(node.left);
        values.add(node.val);
        inorder(node.right);
    }

    public int getMinimumDifference(TreeNode root) {
        inorder(root); // fills values in sorted order (BST property)

        int minDiff = Integer.MAX_VALUE;

        // compare all pairs — but since list is sorted, adjacent pairs are enough
        // (brute approach shown: compare every pair)
        for (int i = 0; i < values.size(); i++) {
            for (int j = i + 1; j < values.size(); j++) {
                minDiff = Math.min(minDiff, values.get(j) - values.get(i));
            }
        }

        return minDiff;
    }

    public static void main(String[] args) {
        MinimumAbsoluteDifferenceInBSTBrute sol = new MinimumAbsoluteDifferenceInBSTBrute();

        //   4
        //  / \
        // 2   6
        // |
        // 1 3
        TreeNode root = new TreeNode(4,
            new TreeNode(2, new TreeNode(1), new TreeNode(3)),
            new TreeNode(6)
        );

        System.out.println(sol.getMinimumDifference(root)); // Expected: 1
    }
}
