// ============================================================
// Problem  : Validate Binary Search Tree
// Approach : Brute Force — inorder traversal collects all values.
//            In a valid BST, inorder output must be strictly ascending.
// Time     : O(n)
// Space    : O(n) for the list
// LeetCode : https://leetcode.com/problems/validate-binary-search-tree/
// ============================================================

import java.util.ArrayList;
import java.util.List;

public class ValidateBinarySearchTreeBrute {

    static class TreeNode {
        int val;
        TreeNode left, right;
        TreeNode(int val) { this.val = val; }
        TreeNode(int val, TreeNode left, TreeNode right) {
            this.val = val; this.left = left; this.right = right;
        }
    }

    private List<Integer> values = new ArrayList<>();

    private void inorder(TreeNode node) {
        if (node == null) return;
        inorder(node.left);
        values.add(node.val);
        inorder(node.right);
    }

    public boolean isValidBST(TreeNode root) {
        inorder(root); // collect all values in inorder

        // check that the list is strictly increasing
        for (int i = 1; i < values.size(); i++) {
            if (values.get(i) <= values.get(i - 1)) {
                return false; // not strictly ascending -> not a valid BST
            }
        }

        return true;
    }

    public static void main(String[] args) {
        ValidateBinarySearchTreeBrute sol = new ValidateBinarySearchTreeBrute();

        //   2
        //  / \
        // 1   3
        TreeNode valid = new TreeNode(2, new TreeNode(1), new TreeNode(3));
        System.out.println(sol.isValidBST(valid)); // Expected: true

        ValidateBinarySearchTreeBrute sol2 = new ValidateBinarySearchTreeBrute();
        //   5
        //  / \
        // 1   4
        //    / \
        //   3   6
        TreeNode invalid = new TreeNode(5,
            new TreeNode(1),
            new TreeNode(4, new TreeNode(3), new TreeNode(6))
        );
        System.out.println(sol2.isValidBST(invalid)); // Expected: false
    }
}
