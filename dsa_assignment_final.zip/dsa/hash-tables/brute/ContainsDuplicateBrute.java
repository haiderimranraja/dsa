// ============================================================
// Problem  : Contains Duplicate
// Approach : Brute Force — sort array, then compare adjacent elements.
//            Duplicates will be next to each other after sorting.
// Time     : O(n log n)
// Space    : O(1) extra (in-place sort)
// LeetCode : https://leetcode.com/problems/contains-duplicate/
// ============================================================

import java.util.Arrays;

public class ContainsDuplicateBrute {

    public boolean containsDuplicate(int[] nums) {
        Arrays.sort(nums); // sort so duplicates become adjacent

        for (int i = 0; i < nums.length - 1; i++) {
            if (nums[i] == nums[i + 1]) {
                return true; // found adjacent duplicate
            }
        }

        return false; // no duplicates found
    }

    public static void main(String[] args) {
        ContainsDuplicateBrute sol = new ContainsDuplicateBrute();

        System.out.println(sol.containsDuplicate(new int[]{1, 2, 3, 1}));    // Expected: true
        System.out.println(sol.containsDuplicate(new int[]{1, 2, 3, 4}));    // Expected: false
        System.out.println(sol.containsDuplicate(new int[]{1, 1, 1, 3, 3, 4, 3, 2, 4, 2})); // true
    }
}
