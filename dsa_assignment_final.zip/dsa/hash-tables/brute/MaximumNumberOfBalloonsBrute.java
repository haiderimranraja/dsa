// ============================================================
// Problem  : Maximum Number of Balloons
// Approach : Brute Force — manually count each required character,
//            then apply floor division with careful attention to
//            'l' and 'o' which appear twice in "balloon"
// Time     : O(n)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/maximum-number-of-balloons/
// ============================================================

public class MaximumNumberOfBalloonsBrute {

    public int maxNumberOfBalloons(String text) {
        // count occurrences of each character needed for "balloon"
        int b = 0, a = 0, l = 0, o = 0, n = 0;

        for (char c : text.toCharArray()) {
            if      (c == 'b') b++;
            else if (c == 'a') a++;
            else if (c == 'l') l++;
            else if (c == 'o') o++;
            else if (c == 'n') n++;
        }

        // "balloon" needs: b(1), a(1), l(2), o(2), n(1)
        // so divide l and o counts by 2
        l /= 2;
        o /= 2;

        // the minimum determines how many full "balloon"s we can make
        return Math.min(b, Math.min(a, Math.min(l, Math.min(o, n))));
    }

    public static void main(String[] args) {
        MaximumNumberOfBalloonsBrute sol = new MaximumNumberOfBalloonsBrute();

        System.out.println(sol.maxNumberOfBalloons("nlaebolko"));      // Expected: 1
        System.out.println(sol.maxNumberOfBalloons("loonbalxballpoon")); // Expected: 2
        System.out.println(sol.maxNumberOfBalloons("leetcode"));       // Expected: 0
    }
}
