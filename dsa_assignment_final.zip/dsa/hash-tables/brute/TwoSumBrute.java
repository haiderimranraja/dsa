// ============================================================
// Problem  : Two Sum
// Approach : Brute Force — try all pairs (i, j) where i < j
//            Check if nums[i] + nums[j] == target
// Time     : O(n^2)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/two-sum/
// ============================================================

public class TwoSumBrute {

    public int[] twoSum(int[] nums, int target) {
        for (int i = 0; i < nums.length - 1; i++) {
            for (int j = i + 1; j < nums.length; j++) {
                if (nums[i] + nums[j] == target) {
                    return new int[]{i, j}; // found the pair
                }
            }
        }
        return new int[]{}; // no solution (guaranteed there is one per problem)
    }

    public static void main(String[] args) {
        TwoSumBrute sol = new TwoSumBrute();

        int[] result1 = sol.twoSum(new int[]{2, 7, 11, 15}, 9);
        System.out.println(result1[0] + ", " + result1[1]); // Expected: 0, 1

        int[] result2 = sol.twoSum(new int[]{3, 2, 4}, 6);
        System.out.println(result2[0] + ", " + result2[1]); // Expected: 1, 2
    }
}
