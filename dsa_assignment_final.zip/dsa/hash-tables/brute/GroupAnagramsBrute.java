// ============================================================
// Problem  : Group Anagrams
// Approach : Brute Force — compare every pair of strings.
//            Two strings are anagrams if their sorted forms match.
// Time     : O(n^2 * k) where k = average string length
// Space    : O(n) for visited tracking + result
// LeetCode : https://leetcode.com/problems/group-anagrams/
// ============================================================

import java.util.*;

public class GroupAnagramsBrute {

    public List<List<String>> groupAnagrams(String[] strs) {
        List<List<String>> result = new ArrayList<>();
        boolean[] visited = new boolean[strs.length]; // track already-grouped strings

        for (int i = 0; i < strs.length; i++) {
            if (visited[i]) continue; // already placed in a group

            List<String> group = new ArrayList<>();
            group.add(strs[i]);
            visited[i] = true;

            char[] sortedI = strs[i].toCharArray();
            Arrays.sort(sortedI); // sorted version of current string

            // compare against all remaining strings
            for (int j = i + 1; j < strs.length; j++) {
                if (visited[j]) continue;

                char[] sortedJ = strs[j].toCharArray();
                Arrays.sort(sortedJ);

                if (Arrays.equals(sortedI, sortedJ)) {
                    group.add(strs[j]);
                    visited[j] = true; // mark as grouped
                }
            }

            result.add(group);
        }

        return result;
    }

    public static void main(String[] args) {
        GroupAnagramsBrute sol = new GroupAnagramsBrute();

        System.out.println(sol.groupAnagrams(new String[]{"eat", "tea", "tan", "ate", "nat", "bat"}));
        // Expected: [["eat","tea","ate"],["tan","nat"],["bat"]]
    }
}
