// ============================================================
// Problem  : Valid Anagram
// Approach : Brute Force — sort both strings and compare.
//            Anagrams will produce identical sorted strings.
// Time     : O(n log n)
// Space    : O(n) for the char arrays
// LeetCode : https://leetcode.com/problems/valid-anagram/
// ============================================================

import java.util.Arrays;

public class ValidAnagramBrute {

    public boolean isAnagram(String s, String t) {
        if (s.length() != t.length()) return false; // different lengths can't be anagrams

        // convert to char arrays, sort, compare
        char[] sArr = s.toCharArray();
        char[] tArr = t.toCharArray();

        Arrays.sort(sArr);
        Arrays.sort(tArr);

        return Arrays.equals(sArr, tArr); // true if sorted versions match
    }

    public static void main(String[] args) {
        ValidAnagramBrute sol = new ValidAnagramBrute();

        System.out.println(sol.isAnagram("anagram", "nagaram")); // Expected: true
        System.out.println(sol.isAnagram("rat", "car"));         // Expected: false
    }
}
