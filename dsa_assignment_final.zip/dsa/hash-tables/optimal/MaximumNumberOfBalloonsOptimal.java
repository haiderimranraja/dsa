// ============================================================
// Problem  : Maximum Number of Balloons
// Approach : Optimal — HashMap frequency counter, then floor-divide
//            counts for characters appearing twice in "balloon"
//            Generalized and clean approach
// Time     : O(n)
// Space    : O(1) — map has at most 26 keys
// LeetCode : https://leetcode.com/problems/maximum-number-of-balloons/
// ============================================================

import java.util.HashMap;

public class MaximumNumberOfBalloonsOptimal {

    public int maxNumberOfBalloons(String text) {
        HashMap<Character, Integer> freq = new HashMap<>();

        // count frequency of every character in text
        for (char c : text.toCharArray()) {
            freq.put(c, freq.getOrDefault(c, 0) + 1);
        }

        // "balloon" = b(1) a(1) l(2) o(2) n(1)
        // floor-divide for characters that appear more than once in the word
        int b = freq.getOrDefault('b', 0);
        int a = freq.getOrDefault('a', 0);
        int l = freq.getOrDefault('l', 0) / 2; // 'l' appears twice
        int o = freq.getOrDefault('o', 0) / 2; // 'o' appears twice
        int n = freq.getOrDefault('n', 0);

        return Math.min(b, Math.min(a, Math.min(l, Math.min(o, n))));
    }

    public static void main(String[] args) {
        MaximumNumberOfBalloonsOptimal sol = new MaximumNumberOfBalloonsOptimal();

        System.out.println(sol.maxNumberOfBalloons("nlaebolko"));       // Expected: 1
        System.out.println(sol.maxNumberOfBalloons("loonbalxballpoon")); // Expected: 2
        System.out.println(sol.maxNumberOfBalloons("leetcode"));        // Expected: 0
    }
}
