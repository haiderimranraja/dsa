// ============================================================
// Problem  : Group Anagrams
// Approach : Optimal — sort each string as a HashMap key.
//            All anagrams produce the same sorted key.
//            Single pass groups them all in O(n * k log k).
// Time     : O(n * k log k) where n = words, k = avg word length
// Space    : O(n * k) for the map and result
// LeetCode : https://leetcode.com/problems/group-anagrams/
// ============================================================

import java.util.*;

public class GroupAnagramsOptimal {

    public List<List<String>> groupAnagrams(String[] strs) {
        // key = sorted string, value = list of original strings that map to it
        HashMap<String, List<String>> map = new HashMap<>();

        for (String s : strs) {
            char[] chars = s.toCharArray();
            Arrays.sort(chars);               // sorting makes anagram key identical
            String key = new String(chars);   // e.g. "eat","tea","ate" -> "aet"

            // if key not present, create new list; then add current string
            map.computeIfAbsent(key, k -> new ArrayList<>()).add(s);
        }

        return new ArrayList<>(map.values()); // return all grouped lists
    }

    public static void main(String[] args) {
        GroupAnagramsOptimal sol = new GroupAnagramsOptimal();

        System.out.println(sol.groupAnagrams(new String[]{"eat", "tea", "tan", "ate", "nat", "bat"}));
        // Expected: [["eat","tea","ate"],["tan","nat"],["bat"]]
    }
}
