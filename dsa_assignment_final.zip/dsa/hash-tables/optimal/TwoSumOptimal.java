// ============================================================
// Problem  : Two Sum
// Approach : Optimal — HashMap stores each number's index.
//            For every num, check if (target - num) already exists.
//            This eliminates the inner loop entirely.
// Time     : O(n)
// Space    : O(n) for the HashMap
// LeetCode : https://leetcode.com/problems/two-sum/
// ============================================================

import java.util.HashMap;

public class TwoSumOptimal {

    public int[] twoSum(int[] nums, int target) {
        // map: value -> index
        HashMap<Integer, Integer> map = new HashMap<>();

        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i]; // what number do we need to pair with nums[i]?

            if (map.containsKey(complement)) {
                // complement was already seen -> we have our pair
                return new int[]{map.get(complement), i};
            }

            map.put(nums[i], i); // store current number and its index
        }

        return new int[]{}; // guaranteed solution exists
    }

    public static void main(String[] args) {
        TwoSumOptimal sol = new TwoSumOptimal();

        int[] result1 = sol.twoSum(new int[]{2, 7, 11, 15}, 9);
        System.out.println(result1[0] + ", " + result1[1]); // Expected: 0, 1

        int[] result2 = sol.twoSum(new int[]{3, 2, 4}, 6);
        System.out.println(result2[0] + ", " + result2[1]); // Expected: 1, 2
    }
}
