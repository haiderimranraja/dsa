// ============================================================
// Problem  : Contains Duplicate
// Approach : Optimal — HashSet for O(1) lookup.
//            Add each number; if it's already in the set -> duplicate.
// Time     : O(n)
// Space    : O(n) for the HashSet
// LeetCode : https://leetcode.com/problems/contains-duplicate/
// ============================================================

import java.util.HashSet;

public class ContainsDuplicateOptimal {

    public boolean containsDuplicate(int[] nums) {
        HashSet<Integer> seen = new HashSet<>();

        for (int num : nums) {
            if (seen.contains(num)) {
                return true; // already saw this number before
            }
            seen.add(num); // first time seeing it, record it
        }

        return false; // all numbers were unique
    }

    public static void main(String[] args) {
        ContainsDuplicateOptimal sol = new ContainsDuplicateOptimal();

        System.out.println(sol.containsDuplicate(new int[]{1, 2, 3, 1}));    // Expected: true
        System.out.println(sol.containsDuplicate(new int[]{1, 2, 3, 4}));    // Expected: false
        System.out.println(sol.containsDuplicate(new int[]{1, 1, 1, 3, 3, 4, 3, 2, 4, 2})); // true
    }
}
