// ============================================================
// Problem  : Valid Anagram
// Approach : Optimal — frequency array of size 26 (a-z).
//            Increment for chars in s, decrement for chars in t.
//            If all zeros at end -> anagram.
// Time     : O(n)
// Space    : O(1) — fixed 26-size array
// LeetCode : https://leetcode.com/problems/valid-anagram/
// ============================================================

public class ValidAnagramOptimal {

    public boolean isAnagram(String s, String t) {
        if (s.length() != t.length()) return false;

        int[] count = new int[26]; // index 0 = 'a', index 25 = 'z'

        for (int i = 0; i < s.length(); i++) {
            count[s.charAt(i) - 'a']++; // increment for s
            count[t.charAt(i) - 'a']--; // decrement for t
        }

        // if arrays are anagrams, all counts cancel out to 0
        for (int c : count) {
            if (c != 0) return false;
        }

        return true;
    }

    public static void main(String[] args) {
        ValidAnagramOptimal sol = new ValidAnagramOptimal();

        System.out.println(sol.isAnagram("anagram", "nagaram")); // Expected: true
        System.out.println(sol.isAnagram("rat", "car"));         // Expected: false
    }
}
