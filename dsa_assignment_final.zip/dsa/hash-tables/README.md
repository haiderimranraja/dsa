# Hash Tables

Hash tables provide O(1) average-case insertion, deletion, and lookup. They are ideal for frequency counting, fast membership testing, and grouping. In Java, use `HashMap<K,V>` for key-value pairs and `HashSet<E>` for membership testing.

---

## Problem List

| # | Problem | Difficulty | LeetCode |
|---|---------|-----------|----------|
| 1 | Contains Duplicate | Easy | [Link](https://leetcode.com/problems/contains-duplicate/) |
| 2 | Two Sum | Easy | [Link](https://leetcode.com/problems/two-sum/) |
| 3 | Maximum Number of Balloons | Easy | [Link](https://leetcode.com/problems/maximum-number-of-balloons/) |
| 4 | Valid Anagram | Easy | [Link](https://leetcode.com/problems/valid-anagram/) |
| 5 | Group Anagrams | Medium | [Link](https://leetcode.com/problems/group-anagrams/) |

---

## Approach

**Contains Duplicate:** Brute force sorts the array so duplicates become adjacent, then scans — O(n log n). The optimal HashSet approach records seen numbers and returns true the moment a repeat is encountered — O(n).

**Two Sum:** Brute force tries all pairs in O(n²). The optimal HashMap approach stores each number's index as we scan; for every number, we check if its complement (target − num) already exists in the map. This collapses the inner loop entirely — O(n).

**Maximum Number of Balloons:** Count occurrences of b, a, l, o, n. The key insight is that 'l' and 'o' each appear twice in "balloon", so their counts must be floor-divided by 2. The minimum across all five determines how many complete words can be formed.

**Valid Anagram:** Brute force sorts both strings and compares — O(n log n). The optimal frequency array approach uses a fixed-size int[26] array: increment for characters in `s`, decrement for `t`. If all values are zero at the end, they're anagrams — O(n), O(1) space.

**Group Anagrams:** Brute force compares every pair — O(n² × k). The optimal HashMap approach sorts each string to produce a canonical key; all anagrams share the same sorted key and get grouped under it — O(n × k log k).

---

## Complexity Table

| Problem | Brute Time | Brute Space | Optimal Time | Optimal Space |
|---------|-----------|-------------|-------------|---------------|
| Contains Duplicate | O(n log n) | O(1) | O(n) | O(n) |
| Two Sum | O(n²) | O(1) | O(n) | O(n) |
| Max Balloons | O(n) | O(1) | O(n) | O(1) |
| Valid Anagram | O(n log n) | O(n) | O(n) | O(1) |
| Group Anagrams | O(n² × k) | O(n) | O(n × k log k) | O(n × k) |

---

## How to Run

```bash
javac ContainsDuplicateBrute.java && java ContainsDuplicateBrute
javac ContainsDuplicateOptimal.java && java ContainsDuplicateOptimal

javac TwoSumBrute.java && java TwoSumBrute
javac TwoSumOptimal.java && java TwoSumOptimal

javac MaximumNumberOfBalloonsBrute.java && java MaximumNumberOfBalloonsBrute
javac ValidAnagramBrute.java && java ValidAnagramBrute
javac GroupAnagramsBrute.java && java GroupAnagramsBrute
```
