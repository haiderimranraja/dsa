// ============================================================
// Problem  : Remove Duplicates from Sorted List
// Approach : Brute Force — convert to ArrayList, remove duplicates,
//            then rebuild the linked list
// Time     : O(n)
// Space    : O(n) extra for the ArrayList
// LeetCode : https://leetcode.com/problems/remove-duplicates-from-sorted-list/
// ============================================================

import java.util.ArrayList;
import java.util.List;

public class RemoveDuplicatesFromSortedListBrute {

    static class ListNode {
        int val;
        ListNode next;
        ListNode(int val) { this.val = val; }
        ListNode(int val, ListNode next) { this.val = val; this.next = next; }
    }

    public ListNode deleteDuplicates(ListNode head) {
        if (head == null) return null;

        // collect all unique values in order
        List<Integer> unique = new ArrayList<>();
        ListNode curr = head;

        while (curr != null) {
            // add only if list is empty or last added value is different
            if (unique.isEmpty() || unique.get(unique.size() - 1) != curr.val) {
                unique.add(curr.val);
            }
            curr = curr.next;
        }

        // rebuild linked list from unique values
        ListNode dummy = new ListNode(0);
        ListNode node  = dummy;
        for (int val : unique) {
            node.next = new ListNode(val);
            node = node.next;
        }

        return dummy.next;
    }

    static void print(ListNode head) {
        while (head != null) {
            System.out.print(head.val + " -> ");
            head = head.next;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        RemoveDuplicatesFromSortedListBrute sol = new RemoveDuplicatesFromSortedListBrute();

        ListNode l1 = new ListNode(1, new ListNode(1, new ListNode(2)));
        print(sol.deleteDuplicates(l1)); // Expected: 1 -> 2 -> null

        ListNode l2 = new ListNode(1, new ListNode(1, new ListNode(2,
                      new ListNode(3, new ListNode(3)))));
        print(sol.deleteDuplicates(l2)); // Expected: 1 -> 2 -> 3 -> null
    }
}
