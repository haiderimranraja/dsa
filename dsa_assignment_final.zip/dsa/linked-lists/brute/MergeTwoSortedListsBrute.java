// ============================================================
// Problem  : Merge Two Sorted Lists
// Approach : Brute Force — collect all values from both lists into
//            an array, sort it, then rebuild a new linked list
// Time     : O((n+m) log(n+m)) for sorting
// Space    : O(n + m) for the array
// LeetCode : https://leetcode.com/problems/merge-two-sorted-lists/
// ============================================================

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MergeTwoSortedListsBrute {

    static class ListNode {
        int val;
        ListNode next;
        ListNode(int val) { this.val = val; }
        ListNode(int val, ListNode next) { this.val = val; this.next = next; }
    }

    public ListNode mergeTwoLists(ListNode list1, ListNode list2) {
        List<Integer> values = new ArrayList<>();

        // collect all values from both lists
        while (list1 != null) { values.add(list1.val); list1 = list1.next; }
        while (list2 != null) { values.add(list2.val); list2 = list2.next; }

        Collections.sort(values); // sort combined values

        // rebuild a sorted linked list from the values
        ListNode dummy = new ListNode(0);
        ListNode curr  = dummy;
        for (int val : values) {
            curr.next = new ListNode(val);
            curr = curr.next;
        }

        return dummy.next;
    }

    static void print(ListNode head) {
        while (head != null) {
            System.out.print(head.val + " -> ");
            head = head.next;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        MergeTwoSortedListsBrute sol = new MergeTwoSortedListsBrute();

        ListNode l1 = new ListNode(1, new ListNode(2, new ListNode(4)));
        ListNode l2 = new ListNode(1, new ListNode(3, new ListNode(4)));
        print(sol.mergeTwoLists(l1, l2)); // Expected: 1 -> 1 -> 2 -> 3 -> 4 -> 4 -> null
    }
}
