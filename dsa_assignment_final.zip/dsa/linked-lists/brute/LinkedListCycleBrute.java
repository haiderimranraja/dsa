// ============================================================
// Problem  : Linked List Cycle
// Approach : Brute Force — store visited nodes in a HashSet.
//            If we revisit a node, there's a cycle.
// Time     : O(n)
// Space    : O(n) for the HashSet
// LeetCode : https://leetcode.com/problems/linked-list-cycle/
// ============================================================

import java.util.HashSet;

public class LinkedListCycleBrute {

    static class ListNode {
        int val;
        ListNode next;
        ListNode(int val) { this.val = val; }
    }

    public boolean hasCycle(ListNode head) {
        HashSet<ListNode> visited = new HashSet<>(); // stores node references, not values

        ListNode curr = head;
        while (curr != null) {
            if (visited.contains(curr)) {
                return true; // we've seen this exact node before -> cycle!
            }
            visited.add(curr); // mark this node as visited
            curr = curr.next;
        }

        return false; // reached end of list -> no cycle
    }

    public static void main(String[] args) {
        LinkedListCycleBrute sol = new LinkedListCycleBrute();

        // Create: 3 -> 2 -> 0 -> -4 -> (back to 2)
        ListNode n1 = new ListNode(3);
        ListNode n2 = new ListNode(2);
        ListNode n3 = new ListNode(0);
        ListNode n4 = new ListNode(-4);
        n1.next = n2; n2.next = n3; n3.next = n4; n4.next = n2; // cycle!

        System.out.println(sol.hasCycle(n1)); // Expected: true

        // No cycle: 1 -> 2
        ListNode a = new ListNode(1);
        ListNode b = new ListNode(2);
        a.next = b;
        System.out.println(sol.hasCycle(a)); // Expected: false
    }
}
