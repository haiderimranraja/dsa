# Linked Lists

Linked lists store elements in nodes connected by pointers, allowing O(1) insert/delete at known positions but O(n) search. Mastering pointer manipulation — especially the fast/slow pointer trick — is essential for technical interviews.

---

## Problem List

| # | Problem | Difficulty | LeetCode |
|---|---------|-----------|----------|
| 1 | Remove Duplicates from Sorted List | Easy | [Link](https://leetcode.com/problems/remove-duplicates-from-sorted-list/) |
| 2 | Linked List Cycle | Easy | [Link](https://leetcode.com/problems/linked-list-cycle/) |
| 3 | Merge Two Sorted Lists | Easy | [Link](https://leetcode.com/problems/merge-two-sorted-lists/) |

---

## Approach

**Remove Duplicates from Sorted List:** The brute force collects values into an ArrayList, deduplicates, then rebuilds the list — O(n) time but O(n) extra space. The optimal single-pointer in-place approach checks if the current node's value equals its next node's value; if so, bypass the next node entirely — O(n) time, O(1) space.

**Linked List Cycle:** The brute force stores every visited node reference in a HashSet — if a node is seen again, there is a cycle. O(n) time, O(n) space. The optimal Floyd's cycle detection algorithm uses two pointers: `slow` moves one step, `fast` moves two. If a cycle exists, fast will eventually lap slow and they will meet — O(n) time, O(1) space.

**Merge Two Sorted Lists:** The brute force collects all values from both lists, sorts them, and rebuilds — O((n+m) log(n+m)) time, O(n+m) space. The optimal two-pointer merge uses a dummy head node; compare the front of each list and attach the smaller node, then advance that pointer. Append any remaining nodes at the end — O(n+m) time, O(1) extra space.

---

## Complexity Table

| Problem | Brute Time | Brute Space | Optimal Time | Optimal Space |
|---------|-----------|-------------|-------------|---------------|
| Remove Duplicates | O(n) | O(n) | O(n) | O(1) |
| Linked List Cycle | O(n) | O(n) | O(n) | O(1) |
| Merge Two Sorted Lists | O((n+m) log(n+m)) | O(n+m) | O(n+m) | O(1) |

---

## How to Run

```bash
javac RemoveDuplicatesFromSortedListBrute.java && java RemoveDuplicatesFromSortedListBrute
javac RemoveDuplicatesFromSortedListOptimal.java && java RemoveDuplicatesFromSortedListOptimal

javac LinkedListCycleBrute.java && java LinkedListCycleBrute
javac LinkedListCycleOptimal.java && java LinkedListCycleOptimal

javac MergeTwoSortedListsBrute.java && java MergeTwoSortedListsBrute
javac MergeTwoSortedListsOptimal.java && java MergeTwoSortedListsOptimal
```
