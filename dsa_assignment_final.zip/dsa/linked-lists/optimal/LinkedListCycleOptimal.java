// ============================================================
// Problem  : Linked List Cycle
// Approach : Optimal — Floyd's Cycle Detection (fast/slow pointers).
//            slow moves 1 step, fast moves 2 steps.
//            If there's a cycle, fast will eventually lap slow and they meet.
//            If no cycle, fast reaches null.
// Time     : O(n)
// Space    : O(1) — no extra data structures!
// LeetCode : https://leetcode.com/problems/linked-list-cycle/
// ============================================================

public class LinkedListCycleOptimal {

    static class ListNode {
        int val;
        ListNode next;
        ListNode(int val) { this.val = val; }
    }

    public boolean hasCycle(ListNode head) {
        ListNode slow = head; // moves 1 step at a time
        ListNode fast = head; // moves 2 steps at a time

        while (fast != null && fast.next != null) {
            slow = slow.next;       // 1 step
            fast = fast.next.next;  // 2 steps

            if (slow == fast) {
                return true; // fast lapped slow -> cycle detected!
            }
        }

        return false; // fast hit null -> no cycle
    }

    public static void main(String[] args) {
        LinkedListCycleOptimal sol = new LinkedListCycleOptimal();

        ListNode n1 = new ListNode(3);
        ListNode n2 = new ListNode(2);
        ListNode n3 = new ListNode(0);
        ListNode n4 = new ListNode(-4);
        n1.next = n2; n2.next = n3; n3.next = n4; n4.next = n2; // cycle!

        System.out.println(sol.hasCycle(n1)); // Expected: true

        ListNode a = new ListNode(1);
        ListNode b = new ListNode(2);
        a.next = b;
        System.out.println(sol.hasCycle(a)); // Expected: false
    }
}
