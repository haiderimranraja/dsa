// ============================================================
// Problem  : Merge Two Sorted Lists
// Approach : Optimal — two-pointer merge in-place using a dummy head.
//            Compare list1 and list2 node values, attach the smaller
//            one to result. Append remaining nodes at the end.
// Time     : O(n + m)
// Space    : O(1) extra (reuses existing nodes, only dummy is new)
// LeetCode : https://leetcode.com/problems/merge-two-sorted-lists/
// ============================================================

public class MergeTwoSortedListsOptimal {

    static class ListNode {
        int val;
        ListNode next;
        ListNode(int val) { this.val = val; }
        ListNode(int val, ListNode next) { this.val = val; this.next = next; }
    }

    public ListNode mergeTwoLists(ListNode list1, ListNode list2) {
        ListNode dummy = new ListNode(0); // placeholder head
        ListNode curr  = dummy;

        // merge while both lists have nodes
        while (list1 != null && list2 != null) {
            if (list1.val <= list2.val) {
                curr.next = list1; // attach smaller node
                list1 = list1.next;
            } else {
                curr.next = list2;
                list2 = list2.next;
            }
            curr = curr.next;
        }

        // attach the remaining nodes (one list might be longer)
        curr.next = (list1 != null) ? list1 : list2;

        return dummy.next; // skip the dummy head
    }

    static void print(ListNode head) {
        while (head != null) {
            System.out.print(head.val + " -> ");
            head = head.next;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        MergeTwoSortedListsOptimal sol = new MergeTwoSortedListsOptimal();

        ListNode l1 = new ListNode(1, new ListNode(2, new ListNode(4)));
        ListNode l2 = new ListNode(1, new ListNode(3, new ListNode(4)));
        print(sol.mergeTwoLists(l1, l2)); // Expected: 1 -> 1 -> 2 -> 3 -> 4 -> 4 -> null
    }
}
