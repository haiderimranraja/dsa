// ============================================================
// Problem  : Remove Duplicates from Sorted List
// Approach : Optimal — single pointer in-place.
//            If current.val == current.next.val, skip next node.
//            Otherwise advance pointer. No extra space needed.
// Time     : O(n)
// Space    : O(1)
// LeetCode : https://leetcode.com/problems/remove-duplicates-from-sorted-list/
// ============================================================

public class RemoveDuplicatesFromSortedListOptimal {

    static class ListNode {
        int val;
        ListNode next;
        ListNode(int val) { this.val = val; }
        ListNode(int val, ListNode next) { this.val = val; this.next = next; }
    }

    public ListNode deleteDuplicates(ListNode head) {
        ListNode curr = head;

        while (curr != null && curr.next != null) {
            if (curr.val == curr.next.val) {
                // skip the duplicate node by bypassing it
                curr.next = curr.next.next;
            } else {
                curr = curr.next; // only advance if no duplicate
            }
        }

        return head;
    }

    static void print(ListNode head) {
        while (head != null) {
            System.out.print(head.val + " -> ");
            head = head.next;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        RemoveDuplicatesFromSortedListOptimal sol = new RemoveDuplicatesFromSortedListOptimal();

        ListNode l1 = new ListNode(1, new ListNode(1, new ListNode(2)));
        print(sol.deleteDuplicates(l1)); // Expected: 1 -> 2 -> null

        ListNode l2 = new ListNode(1, new ListNode(1, new ListNode(2,
                      new ListNode(3, new ListNode(3)))));
        print(sol.deleteDuplicates(l2)); // Expected: 1 -> 2 -> 3 -> null
    }
}
